package cn.coding.crudexample.controller;

import cn.coding.crudexample.entity.CustomerServiceQueue;
import cn.coding.crudexample.service.CustomerServiceQueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CustomerServiceQueueController {

    @Autowired
    private CustomerServiceQueueService service;

    @PostMapping("/addCustomerServiceQueue")
    public CustomerServiceQueue addCustomerServiceQueue(@RequestBody CustomerServiceQueue customerServiceQueue) {
        return service.saveCustomerServiceQueue(customerServiceQueue);
    }
    @PostMapping("/addCustomerServiceQueues")
    public List<CustomerServiceQueue> addCustomerServiceQueues(@RequestBody List<CustomerServiceQueue> customerServiceQueues) {
        return service.saveCustomerServiceQueues(customerServiceQueues);
    }
    @GetMapping("/customerServiceQueues")
    public List<CustomerServiceQueue> findAllCustomerServiceQueues() {
        return service.getCustomerServiceQueues();
    }
    @GetMapping("/customerServiceQueue/{username}")
    public CustomerServiceQueue findCustomerServiceQueueByUsername(@PathVariable String username) {
        return service.getCustomerServiceQueueByUsername(username);
    }
    @PutMapping("/updateCustomerServiceQueue")
    public CustomerServiceQueue updateCustomerServiceQueue(@RequestBody CustomerServiceQueue customerServiceQueue) {
        return service.updateCustomerServiceQueue(customerServiceQueue);
    }
    @DeleteMapping("/deleteCustomerServiceQueue/{csid}")
    public String deleteCustomerServiceQueue(int csid){

        return service.deleteCustomerServiceQueue(csid);
    }
}
