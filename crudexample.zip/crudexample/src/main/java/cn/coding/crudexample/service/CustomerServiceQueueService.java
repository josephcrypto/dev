package cn.coding.crudexample.service;

import cn.coding.crudexample.entity.CustomerServiceQueue;
import cn.coding.crudexample.repository.CustomerServiceQueueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceQueueService {

    @Autowired
    private CustomerServiceQueueRepository customerServiceQueueRepository;

    public List<CustomerServiceQueue> getCustomerServiceQueues() {
        return customerServiceQueueRepository.findAll();
    }

    public CustomerServiceQueue saveCustomerServiceQueue(CustomerServiceQueue customerServiceQueue) {
        return customerServiceQueueRepository.save(customerServiceQueue);
    }

    public List<CustomerServiceQueue> saveCustomerServiceQueues(List<CustomerServiceQueue> customerServiceQueues) {
        return customerServiceQueueRepository.saveAll(customerServiceQueues);

    }

    public CustomerServiceQueue getCustomerServiceQueueByUsername(String username) {
        return customerServiceQueueRepository.findByUsername(username);
    }
    public String deleteCustomerServiceQueue(int csid) {
        customerServiceQueueRepository.deleteById(csid);
        return "customer service message has been delete ! " + csid;
    }
    public CustomerServiceQueue updateCustomerServiceQueue(CustomerServiceQueue customerServiceQueue){
        CustomerServiceQueue existingCustomerServiceQueue = customerServiceQueueRepository.findById(customerServiceQueue.getCsid()).orElse(null);
        existingCustomerServiceQueue.setUsername(customerServiceQueue.getUsername());
        existingCustomerServiceQueue.setPassword(customerServiceQueue.getPassword());
        existingCustomerServiceQueue.setActive(customerServiceQueue.getActive());
        existingCustomerServiceQueue.setSalt(customerServiceQueue.getSalt());
        existingCustomerServiceQueue.setRealname(customerServiceQueue.getRealname());
        return customerServiceQueueRepository.save(existingCustomerServiceQueue);
    }
}
