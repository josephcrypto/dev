package cn.coding.crudexample.entity;

import lombok.*;


import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;

@Setter
@Getter
@Entity
@Table(name = "chat_queue")
public class Queue implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int qid;
    private String customerid;
    private Date created_at;
    private Byte active;
    private int csid;
    private String ip;
    private String country;
    private String province;
    private String city;
    private String isp;

}
