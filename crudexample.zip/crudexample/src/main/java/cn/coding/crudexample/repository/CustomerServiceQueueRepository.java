package cn.coding.crudexample.repository;

import cn.coding.crudexample.entity.CustomerServiceQueue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomerServiceQueueRepository extends JpaRepository<CustomerServiceQueue, Integer> {

    CustomerServiceQueue findByUsername(String username);
}
