package cn.coding.crudexample.controller;

import cn.coding.crudexample.entity.Queue;
import cn.coding.crudexample.service.QueueService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;

@RestController
public class QueueController {

    @Autowired
    private QueueService queueService;

    @PostMapping("/addQueue")
    public Queue addQueue(@RequestBody Queue queue) {

        return queueService.saveQueue(queue);
    }

    @PostMapping("/addQueues")
    public List<Queue> addQueues(@RequestBody List<Queue> queues) {

        return queueService.saveQueues(queues);
    }
    @GetMapping("/queues")
    public List<Queue> findAllQueues() {

        return queueService.getQueues();
    }
    @GetMapping("/queueById/{qid}")
    public Queue findQueueById(@PathVariable int qid) {

        return queueService.getQueueById(qid);
    }
    @GetMapping("/queueByProvince/{province}")
    public Queue findByProvince(@PathVariable String province) {
        return queueService.getQueueByProvince(province);
    }

    @PutMapping("/update")
    public Queue updateQueue(@RequestBody Queue queue) {
        return queueService.updateQueue(queue);
    }

    @DeleteMapping("/delete/{qid}")
    public String deleteQueue(int qid){
        return queueService.deleteQueue(qid);
    }
}