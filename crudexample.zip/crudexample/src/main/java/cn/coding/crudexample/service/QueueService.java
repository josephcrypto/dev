package cn.coding.crudexample.service;

import cn.coding.crudexample.entity.Queue;
import cn.coding.crudexample.repository.QueueRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class QueueService {

    @Autowired
    private QueueRepository repository;

    public Queue saveQueue(Queue queue){
        return repository.save(queue);
    }

    public List<Queue> saveQueues(List<Queue> queues) {
        return repository.saveAll(queues);
    }
    public List<Queue> getQueues(){
        return repository.findAll();
    }
    public Queue getQueueById(int qid) {
        return repository.findById(qid).get();
    }
    public Queue getQueueByCity(String city) {
        return repository.findByCity(city);
    }
    public String deleteQueue(int qid) {
        repository.deleteById(qid);
        return "message has been delete ! " + qid;
    }
    public Queue getQueueByProvince(String province) {
        return repository.findByProvince(province);
    }
    public Queue updateQueue(Queue queue){
        Queue existingQueue = repository.findById(queue.getQid()).orElse(null);
        existingQueue.setActive(queue.getActive());
        existingQueue.setCity(queue.getCity());
        existingQueue.setCountry(queue.getCountry());
        existingQueue.setCreated_at(queue.getCreated_at());
        existingQueue.setCsid(queue.getCsid());
        existingQueue.setCustomerid(queue.getCustomerid());

        return repository.save(existingQueue);
    }


}
