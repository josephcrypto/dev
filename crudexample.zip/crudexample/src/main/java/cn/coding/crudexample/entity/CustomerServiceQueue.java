package cn.coding.crudexample.entity;

import lombok.*;


import javax.persistence.*;
import java.io.Serializable;


@Getter
@Setter
@Entity
@Table(name = "tb_customer_service")
public class CustomerServiceQueue implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int csid;
    private String username;
    private String password;
    private String active;
    private String salt;
    private String realname;

}
