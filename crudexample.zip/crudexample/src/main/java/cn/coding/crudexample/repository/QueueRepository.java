package cn.coding.crudexample.repository;

import cn.coding.crudexample.entity.Queue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface QueueRepository extends JpaRepository<Queue, Integer> {

    Queue findByCity(String city);

    Queue findByProvince(String province);
}
