package cn.coding.crudexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
